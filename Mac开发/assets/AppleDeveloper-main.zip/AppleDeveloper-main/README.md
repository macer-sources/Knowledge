# AppleDeveloperAppDemo

A demo of NSOutlineView

# Preview

![SKsywoGWg1HvEja](./Screen/2.jpg)

# Notice

If the App icon is not displayed, please download SF Symbols

https://developer.apple.com/sf-symbols/
